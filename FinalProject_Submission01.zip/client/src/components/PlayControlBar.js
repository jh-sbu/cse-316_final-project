import { FastForward, FastRewind, PlayArrow, Stop } from "@mui/icons-material";
import { Grid, IconButton } from "@mui/material";
import { Box } from "@mui/system";
import { useContext } from "react";
import PlaylistStoreContext from "../store/PlaylistStore";

export default function PlayControlBar(props) {

    const { store } = useContext(PlaylistStoreContext);

    const handleClickRewind = (event) => {
        event.stopPropagation();
        console.log("Not implemented!");
    }

    const handleClickStop = (event) => {
        event.stopPropagation();
        console.log("Stop not implemented!");
    }

    const handleClickPlay = (event) => {
        event.stopPropagation();
        console.log("Play not implemented!");
    }

    const handleClickFastforward = (event) => {
        event.stopPropagation();
        console.log("Fast Forward not implemented!");
    }

    return (
        <Grid container direction="row" justifyContent={"center"}>
            <IconButton onClick={handleClickRewind}>
                <FastRewind />
            </IconButton>

            <IconButton onClick={handleClickStop}>
                <Stop />
            </IconButton>

            <IconButton onClick={handleClickPlay}>
                <PlayArrow />
            </IconButton>

            <IconButton onClick={handleClickFastforward}>
                <FastForward />
            </IconButton>
        </Grid>
    )

}